import "/node_modules/.vite/deps/chunk-F3FYYIAV.js?v=4002ca8f";

// node_modules/@auth/sveltekit/client.js
import { base } from "/node_modules/@sveltejs/kit/src/runtime/app/paths/index.js?v=4002ca8f";
async function signIn(providerId, options, authorizationParams) {
  const { callbackUrl = window.location.href, redirect = true } = options ?? {};
  const isCredentials = providerId === "credentials";
  const isEmail = providerId === "email";
  const isSupportingReturn = isCredentials || isEmail;
  const basePath = base ?? "";
  const signInUrl = `${basePath}/auth/${isCredentials ? "callback" : "signin"}/${providerId}`;
  const _signInUrl = `${signInUrl}?${new URLSearchParams(authorizationParams)}`;
  const csrfTokenResponse = await fetch(`${basePath}/auth/csrf`);
  const { csrfToken } = await csrfTokenResponse.json();
  const res = await fetch(_signInUrl, {
    method: "post",
    headers: {
      "Content-Type": "application/x-www-form-urlencoded",
      "X-Auth-Return-Redirect": "1"
    },
    // @ts-ignore
    body: new URLSearchParams({
      ...options,
      csrfToken,
      callbackUrl
    })
  });
  const data = await res.clone().json();
  if (redirect || !isSupportingReturn) {
    window.location.href = data.url ?? callbackUrl;
    if (data.url.includes("#"))
      window.location.reload();
    return;
  }
  return res;
}
async function signOut(options) {
  const { callbackUrl = window.location.href } = options ?? {};
  const basePath = base ?? "";
  const csrfTokenResponse = await fetch(`${basePath}/auth/csrf`);
  const { csrfToken } = await csrfTokenResponse.json();
  const res = await fetch(`${basePath}/auth/signout`, {
    method: "post",
    headers: {
      "Content-Type": "application/x-www-form-urlencoded",
      "X-Auth-Return-Redirect": "1"
    },
    body: new URLSearchParams({
      csrfToken,
      callbackUrl
    })
  });
  const data = await res.json();
  const url = data.url ?? callbackUrl;
  window.location.href = url;
  if (url.includes("#"))
    window.location.reload();
}
export {
  signIn,
  signOut
};
//# sourceMappingURL=@auth_sveltekit_client.js.map
