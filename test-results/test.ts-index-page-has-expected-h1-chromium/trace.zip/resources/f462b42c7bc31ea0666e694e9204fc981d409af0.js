// node_modules/svelte/src/shared/version.js
var VERSION = "4.2.8";
var PUBLIC_VERSION = "4";

export {
  VERSION,
  PUBLIC_VERSION
};
//# sourceMappingURL=chunk-ZUGQ3PSC.js.map
