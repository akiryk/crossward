import {
  PUBLIC_VERSION
} from "/node_modules/.vite/deps/chunk-ZUGQ3PSC.js?v=4002ca8f";
import "/node_modules/.vite/deps/chunk-F3FYYIAV.js?v=4002ca8f";

// node_modules/svelte/src/runtime/internal/disclose-version/index.js
if (typeof window !== "undefined")
  (window.__svelte || (window.__svelte = { v: /* @__PURE__ */ new Set() })).v.add(PUBLIC_VERSION);
//# sourceMappingURL=svelte_internal_disclose-version.js.map
