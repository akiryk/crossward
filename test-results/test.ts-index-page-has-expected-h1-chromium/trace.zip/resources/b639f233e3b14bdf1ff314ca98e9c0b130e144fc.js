import "/node_modules/.vite/deps/chunk-F3FYYIAV.js?v=4002ca8f";

// node_modules/esm-env/dev-browser.js
var BROWSER = true;
var DEV = true;
export {
  BROWSER,
  DEV
};
//# sourceMappingURL=esm-env.js.map
